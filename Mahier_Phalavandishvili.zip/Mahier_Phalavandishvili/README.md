# Min_Makespan_projet

Vous trouverez dans le répertoire **/code/src** l'intégralité du code source.

Une fois dans le répertoire **/code**, utilisez les commandes **make** et **make clean** pour respectivement compiler le code, puis créer l'exécutable et respectivement supprimer ces derniers.

Vous pouvez ensuite exécuter le programme comme suit : **./main.exe** .

Un fichier *data.txt* est également présent dans ce réperoire, il contient les données de l'exercice 2 du TD 3. Il peut ainsi servir dans le cas de la création d'une instance à partir d'un fichier.

Notez que l'interface est *user-friendly*, il sera donc indiqué lorsque nécessaire les instructions à suivre (pour la création d'instance au clavier nottamment). Aussi vous pourrez répéter vos manipulation plusieurs fois de suite sans avoir à relancer le programme.
